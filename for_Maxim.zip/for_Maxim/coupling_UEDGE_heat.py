import sys
import math
import numpy as np
from uedge.rundt import *
import matplotlib.pyplot as plt
from uedge import *
from uedge.hdf5 import *
from uedge.rundt import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import uedge_mvu.analysis as mana
import UEDGE_utils.analysis as ana
import pandas as pd
from runcase import *



setGrid()
setPhysics(impFrac=0, fluxLimit=True)
setDChi(kye=1.0, kyi=1.0, difni=0.5, nonuniform=True)
setBoundaryConditions(ncore=6.0e19, pcoree=2.5e6, pcorei=2.5e6, recycp=0.98)
setimpmodel(impmodel=True)

bbb.fphysyrb = 1.00  
bbb.cion = 3
bbb.oldseec = 0
#bbb.restart = 1
bbb.icntnunk = 0

print('restore a flat state with Li den 1e-10, Te and Ti = 1eV')

#hdf5_restore("./final_flat.hdf5") 

#bbb.ftol = 1e-5
#bbb.dtreal = 1e-10
#bbb.issfon = 1 ; bbb.isbcwdt =1
#bbb.itermx = 1000
#bbb.exmain()

bbb.allocate()
bbb.tes=1*bbb.ev
bbb.tis=1*bbb.ev                                                
bbb.nis = 1e17
bbb.ne = 1e17
bbb.ngs=1e16
bbb.ups=0
bbb.ftol = 1e-5; bbb.dtreal = 1e-10
bbb.itermx = 1000
bbb.isbcwdt = 1
bbb.exmain()

print('Max te is :', np.max(bbb.te/bbb.ev))
print('Max ne is :', np.max(bbb.ne))
print('Max ti is :', np.max(bbb.ti/bbb.ev))

q_perp_div = ana.PsurfOuter()
q_perp_div = (q_perp_div * np.cos(com.angfx[com.nx, :])) / com.sxnp[com.nx, :]
q_data = q_perp_div

print('Max q is ', np.max(q_data))

savefile="final_flat"+".hdf5"
hdf5_save(savefile)


Tsurf_max = []
qmax = []
Error = 1
n = 5
i = 0
it = []
previous_q_data = None  

while i <= n:
  
    q_perp_div = ana.PsurfOuter()
    q_perp_div = (q_perp_div * np.cos(com.angfx[com.nx, :])) / com.sxnp[com.nx, :]
    q_data = q_perp_div
    np.save('q_data.npy', q_data)
    q_max2 = np.max(q_data)
    print('q_perp is done')
    print('Max q is :', q_max2)

    # Call the heat code
    print('---Calling heat code----')
    try:
        exec(open("heat_code.py").read())  
    except Exception as e:
        print(f"Error executing heat_code.py: {e}")
        break
    
    Tsurf = final_temperature
    T_max = np.max(Tsurf)
    print('Temp length is :', len(Tsurf))
    print('Peak temp is :', T_max)
    Tsurf_max.append(T_max)
    
    fname = "T_surfit_" + "{:.1f}".format(i) + ".csv"
    print("Saving Tsurf in file: ", fname)
    np.savetxt(fname, Tsurf, delimiter=",")
    
    print('----Heat code completed and output obtained')
    print('---Heat code is done----')
  
    # Update sputtering yield factor and run UEDGE code
    print("Total Li flux is :", len(tot))
    print("phi_Li^Odiv :", np.sum(tot*com.sxnp[com.nx,:]))
    
    if Factor == 0:
        bbb.fphysyrb = "1.00"
    else:
        bbb.fphysyrb = f"{Factor:.2f}"
        
    print('The factor is :', bbb.fphysyrb[0,0])

    Phy_sput_Li = np.sum(bbb.sputflxrb[:,1,0])
    print('Li sput phys is :', Phy_sput_Li)
    
    print("Completed heat code, now running UEDGE code with the updated Li flux")
    
    bbb.restart = 1
    bbb.itermx = 100
    bbb.dtreal = 1e-10
    bbb.ftol = 1e-5
    bbb.issfon = 1
    bbb.isbcwdt=1
    bbb.exmain()
    
   
    j = 0                 
    t_sim = 1e-4           # 0.1 ms simulation time
    bbb.dtreal = 1e-10      
    n_sim = int(t_sim / bbb.dtreal)  #  number of steps
    t_acc = 0.0
    print("Loop condition, tsim < 0.1 ms")
    print(f"Running for {t_sim} s with real timestep {bbb.dtreal}")
    print(f"Total number of steps (n_sim): {n_sim}")

    while j <= n_sim:
        print(f'\nRun UEDGE for {t_sim} s')
        print(f'dtreal: {bbb.dtreal}')
        print(f'n_sim: {n_sim}')
    
        t_acc += bbb.dtreal

        if t_acc <= t_sim:
            bbb.exmain()
            if bbb.iterm != 1:
                bbb.dtreal /= 2
                if bbb.dtreal < 1e-10:
                    print("Warning: timestep too small, setting lower bound")
                    bbb.dtreal = 1e-10
            else:
                bbb.dtreal *= 1.5
            
            j += 1
            print(f"Simulation time is within the desired range: {t_acc} s")
            
        else:
             print(f'Accumulated simulation time is {t_acc} s, which exceeds the desired {t_sim} s')
             break 

        if t_acc > t_sim:
            print(f"Warning: Final accumulated time {t_acc} exceeds the desired {t_sim} s")
        else:
            print(f"Simulation completed within desired time: {t_acc} s")

    if bbb.iterm == 1:
        np.save('final.npy', final_temperature)
        
        q_perp_div = ana.PsurfOuter()
        q_perp_div = (q_perp_div * np.cos(com.angfx[com.nx, :])) / com.sx[com.nx, :]
        q_data = q_perp_div
        q_max = np.max(q_data)
        qmax.append(q_max)
        
        fname = "q_perpit_" + "{:.1f}".format(i) + ".csv"
        print("Saving q_perp in file: ", fname)
        np.savetxt(fname, q_data, delimiter=",")
        
        # Check for convergence based on maximum change in q_data
     #   if previous_q_data is not None:
      #      max_change = np.max(np.abs(q_data/1e6 - previous_q_data/1e6))
      #      print('Maximum change:', max_change)
            
       #     if max_change < 1e-6:
        #        print("Convergence achieved, breaking the loop")
        #        break
        
     
      #  previous_q_data = q_data.copy()
   # else:
    #    print('Not enough data to check convergence.')
    
   
    it.append(i)
    counter = i
    i += 1
    print("Iteration:", i)
    

qmax = np.array(qmax)
tsurf = np.array(Tsurf_max)


plt.figure()
plt.plot(qmax/1e6, tsurf, '--r', marker='*', markersize=14)
plt.xlabel('q$_{\perp, max}^{odiv}$ (MW/m$^2$)', fontsize=20)
plt.ylabel('T$_{surf}^{max}$ ($^\circ$C)', fontsize=20)
plt.title('qmax vs Tmax per iteration')
#plt.legend()
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.grid()
#plt.ylim([0,2])
#plt.xlim([0 ,6])
plt.tight_layout()
plt.savefig('q_max_Temp_it.png', dpi=300)
plt.show()


# Save results to files for plotting 
np.savetxt("qmax.csv", qmax, delimiter=",")
np.savetxt("Tsurf.csv", tsurf, delimiter=",")
np.savetxt("It.csv", it, delimiter=",")


#num_cases = counter
#q_data = []
#for i in range(1, num_cases + 1):
#    fname = f"q_perpit_{i}.csv"
#    print(f"Loading data from file: {fname}")
#    q_data_array = np.loadtxt(fname)
#    q_data.append(q_data_array)

plt.figure(figsize=(12, 8))

for i, data in enumerate(q_data):
    plt.plot(com.yyrb, q_data, label=f'Case {i + 1}')

plt.xlabel('com.yyrb')
plt.ylabel('q Value')
plt.title('Data for Each Case vs. com.rrtb')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


