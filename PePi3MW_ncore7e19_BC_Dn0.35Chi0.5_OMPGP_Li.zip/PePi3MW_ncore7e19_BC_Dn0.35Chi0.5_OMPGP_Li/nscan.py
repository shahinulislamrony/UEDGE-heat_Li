import numpy as np
import matplotlib.pyplot as plt
from uedge.rundt import* 
from uedge.hdf5 import *

bbb.icntnunk=0
bbb.oldseec=0
bbb.restart=1
bbb.isbcwdt=1;


pcore=bbb.pcoree+bbb.pcorei
temid=np.max(bbb.tes[bbb.ixmp,com.iysptrx]/bbb.ev)
tearr=np.array(temid)
pcarr=np.array(pcore)

print("*************")
print("ncore is :", pcore)


while (pcore <= 12e6):

    pcore=pcore+1e6
    print("Trying pcor=", pcore)

    bbb.pcoree = pcore/2
    bbb.pcorei = pcore/2

    bbb.dtreal=1e-10; bbb.isbcwdt=1;
    print("run with dt", bbb.dtreal)
    bbb.exmain()

    bbb.dtreal=1e-9; bbb.isbcwdt=1;
    print("run with dt", bbb.dtreal)
    bbb.exmain()

    bbb.dtreal=1e-8; bbb.isbcwdt=1;
    print("run with dt", bbb.dtreal)
    bbb.exmain()

    bbb.dtreal=1e-7; bbb.isbcwdt=1;
    print("run with dt", bbb.dtreal)
    bbb.exmain()
    
    print("Now run rundt")
    
    rundt(dtreal=1e-7)

    
    if (bbb.iterm==1):
        
         temid=np.max(bbb.tes[bbb.ixmp,com.iysptrx]/bbb.ev)
         tearr=np.append(tearr,temid)
         pcarr=np.append(pcarr,pcore)
                         
         fname="tmp_pcore_"+"{:.1f}".format(pcore)+".h5"
         print("Saving in file: ", fname)
         hdf5_save(fname)
        
     else:
         mu.paws("Failed to converge")
         break

plt.plot(pcarr/1e6,tearr); plt.plot(pcarr/1e6,tearr,"o")
plt.grid(); plt.title("Te [eV] on sepx. at outer midplane vs. Pcore [MW]")
plt.show()
